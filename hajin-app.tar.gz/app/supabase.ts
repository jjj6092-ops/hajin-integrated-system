type Session = { user: { email: string } } | null;
type Listener = (event: string, session: Session) => void;
const listeners = new Set<Listener>();
let session: Session = null;

async function request(path: string, options?: RequestInit) {
  const response = await fetch(path, {
    credentials: "include",
    ...options,
    headers: { "Content-Type": "application/json", ...(options?.headers || {}) },
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(data.error || "요청을 처리하지 못했습니다.");
  return data;
}

export const supabase = {
  auth: {
    async getSession() {
      try {
        const data = await request("/api/session");
        session = data.user ? { user: data.user } : null;
      } catch {
        session = null;
      }
      return { data: { session } };
    },
    onAuthStateChange(listener: Listener) {
      listeners.add(listener);
      return { data: { subscription: { unsubscribe: () => listeners.delete(listener) } } };
    },
    async signInWithPassword({ email, password }: { email: string; password: string }) {
      try {
        const data = await request("/api/login", { method: "POST", body: JSON.stringify({ email, password }) });
        session = { user: data.user };
        listeners.forEach((fn) => fn("SIGNED_IN", session));
        return { error: null };
      } catch (error) {
        return { error };
      }
    },
    async signOut() {
      await request("/api/logout", { method: "POST" }).catch(() => null);
      session = null;
      listeners.forEach((fn) => fn("SIGNED_OUT", null));
    },
  },
};
